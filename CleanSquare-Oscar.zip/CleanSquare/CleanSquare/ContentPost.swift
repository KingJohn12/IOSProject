//
//  ContentPost.swift
//  CleanSquare
//
//  Created by Oscar Fox on 7/24/22.
//

import Foundation

class ContentPost{
    
    var imageName:String
    var profileName:String
    
    init(imageName:String, profileName:String){
        
        self.imageName = imageName
        self.profileName = profileName
        
    }
    
}
