//
//  ViewController.swift
//  CleanSquare
//
//=============================================================================
// PROGRAMMERs:     Oscar Fox, Makaylah Sampson, Alec Joseph
// GROUP NAME:      CleanSquare
// DESCRIPTION:     Social media application that will consist of a login view,
//                  profile view, and content view by utilizing a table.
//
// CLASS:           COP4655
// SECTION:         RVCC 1225
// SEMESTER:        Summer 2022
//
// CERTIFICATION:   We certify that this work is our own and that
//                  none of it is the work of any other person.
//
// CHANGE LOG:      Project created on 7/18/2022.
//
// ISSUES:          None.
//
//=============================================================================

import UIKit

class LoginViewController: UIViewController {

    // State variables
    
    
    
    //------------------------------
    
    override func loadView() {
        super.loadView()
        print("func loadView() called")
        
    }// end loadView
    
    
    //------------------------------
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }// end viewDidLoad

    
    //------------------------------
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("func viewWillAppear(_ animated: Bool) called")
        
    }// end viewWillAppear
    
    
    //------------------------------
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("func viewDidAppear(_ animated: Bool) called")
        
    }// end viewDidAppear
    
    
    //------------------------------
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("func viewWillDisappear(_ animated: Bool) called")
        
    }// end viewWillDisappear
    
    
    //------------------------------
    
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("func viewDidDisappear(_ animated: Bool) called")
        
    }// end viewDidDisappear

}

