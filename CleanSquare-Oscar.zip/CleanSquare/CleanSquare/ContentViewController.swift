//
//  ContentViewController.swift
//  CleanSquare
//
//  Created by Oscar Fox on 7/18/22.
//

import UIKit

class ContentViewController: UIViewController {

    // State variables
    var contentPosts:[ContentPost] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    
    //------------------------------
    
    override func loadView() {
        super.loadView()
        print("ContentViewController -> func loadView() called")
    }
    
    
    //------------------------------

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let post1 = ContentPost(imageName: "Owl", profileName: "Rick")
        let post2 = ContentPost(imageName: "Whale", profileName: "Joseph")
        let post3 = ContentPost(imageName: "Koala", profileName: "Lucy")
        let post4 = ContentPost(imageName: "Fish", profileName: "Paul")
        let post5 = ContentPost(imageName: "Horse", profileName: "Sam")
        let post6 = ContentPost(imageName: "Dog", profileName: "Kennedy")
        
        contentPosts.append(post1)
        contentPosts.append(post2)
        contentPosts.append(post3)
        contentPosts.append(post4)
        contentPosts.append(post5)
        contentPosts.append(post6)
        
        
        tableView.dataSource = self
        tableView.delegate = self
        
    }
    
    
    //------------------------------
    


}// end ContentViewController


extension ContentViewController:UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
}


extension ContentViewController:UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contentPosts.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "postCell") as! ContentPostTableViewCell
        
        cell.postImage.image = UIImage(named: contentPosts[indexPath.row].imageName)
        cell.nameLabel.text = contentPosts[indexPath.row].profileName
        
        return cell
    }
    
    
}
