//
//  Constants.swift
//  CleanSquare
//
//  Created by Oscar Fox on 7/26/22.
//

import Foundation

import UIKit

let APP_DEL = UIApplication.shared.delegate as! AppDelegate
