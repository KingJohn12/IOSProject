//
//  Constants.swift
//  LoginApp
//
//  Created by Alec Joseph on 6/26/22.
//

import Foundation


import UIKit

let APP_DEL = UIApplication.shared.delegate as! AppDelegate
